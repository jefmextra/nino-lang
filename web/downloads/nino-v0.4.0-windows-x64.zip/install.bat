@echo off
setlocal enabledelayedexpansion
title Nino Language Installer
echo ========================================================
echo         Nino High-Assurance Language Installer
echo ========================================================
echo.

set "INSTALL_DIR=%USERPROFILE%\.nino"
set "BIN_DIR=%INSTALL_DIR%\bin"

echo [*] Target installation directory: %INSTALL_DIR%
if not exist "%BIN_DIR%" mkdir "%BIN_DIR%"

echo [*] Installing Nino compiler binary...
copy /Y "%~dp0nino.exe" "%BIN_DIR%\nino.exe" >nul
if errorlevel 1 (
    echo [!] Failed to copy nino.exe.
    pause
    exit /b 1
)

if exist "%~dp0std" (
    echo [*] Installing Standard Library...
    xcopy /E /I /Y "%~dp0std" "%INSTALL_DIR%\std" >nul
)

echo [*] Registering Nino to User PATH...
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USER_PATH=%%B"

echo !USER_PATH! | find /I "%BIN_DIR%" >nul
if errorlevel 1 (
    if defined USER_PATH (
        setx PATH "!USER_PATH!;%BIN_DIR%" >nul
    ) else (
        setx PATH "%BIN_DIR%" >nul
    )
    echo [*] Added %BIN_DIR% to PATH.
) else (
    echo [*] %BIN_DIR% is already in PATH.
)

echo.
echo ========================================================
echo   [OK] Nino Language v0.4.0 installed successfully!
echo   Open a new terminal and type: nino --version
echo ========================================================
echo.
pause
